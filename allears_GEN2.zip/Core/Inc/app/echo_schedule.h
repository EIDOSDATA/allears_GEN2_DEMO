/*
 * echo_schedule.h
 *
 *  Created on: Oct 24, 2022
 *      Author: ECHO
 */

#ifndef INC_APP_ECHO_SCHEDULE_H_
#define INC_APP_ECHO_SCHEDULE_H_

#define ECHO_SCHED_HANDLE_PERIOD						10				/* 10 ms */

void Echo_Sched(void);

#endif /* INC_APP_ECHO_SCHEDULE_H_ */
